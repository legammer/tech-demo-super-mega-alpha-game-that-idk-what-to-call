import ursina as ur
from ursina.prefabs.first_person_controller import FirstPersonController
from direct.actor.Actor import Actor
import threading as th
from time import *
from sys import *
app = ur.Ursina()
ur.window.title = "gametest"
ur.window.icon = "29508.png"
ur.window.position = (150,50)
ur.camera.lens.setNear(0.01)
ground = ur.Entity(model='plane', scale=(500,1,500), texture='white_cube', texture_scale=(100,100), collider='mesh')
render: ur.NodePath
player_capsule = Actor('humanoid.glb')
player_capsule.reparentTo(render)
player_capsule.setScale(.5,.5,.5)
player_capsule.setPos(-3, 0, 3)
player_capsule2 = Actor('humanoid.glb')
player_capsule2.reparentTo(render)
player_capsule2.setScale(.5,.5,.5)
player_capsule2.setPos(-5, 2, 3)
vel_text = ur.Text('setting up the velocity',parent=ur.camera.ui)
vel_text.size = 0.1
vel_text.color = ur.rgb(0,0,1)
min_corner, max_corner = player_capsule.getTightBounds()
player_size = max_corner - min_corner
player = FirstPersonController()
player.gravity = 0.5
player.cursor.visible = True
dashdistance = 10
dashspeed = 50
lockmouse = True
player.camera_pivot.y = 3
playerdefheight = player.camera_pivot.y + .5
playerdefjumpheight = player.jump_height
prev_position = player.position
player_velocity = ur.Vec3(0, 0, 0)
cam_slide = None
closed = False
fasttring = False
leftdashdistance = 0
playingslideanim = False
offset = 0
canfasttr = True
canslide = True
timer = 0
def on_exit():
    global closed
    closed = True
def createstairs():
    global ObjList
    ObjList = []
    for i in range(100):
        ObjList.append(ur.Entity(model='cube',scale=(1,1,1),position=ur.Vec3(0,1,i),color=ur.rgb(i/100,0,0),collider='box'))
    ObjList.append(ur.Entity(model='cube',scale=(1,1,1),position=ur.Vec3(1,2,0),color=ur.rgb(i/100,0,0),collider='box'))
    ObjList.append(ur.Entity(model='cube',scale=(1,1,1),position=ur.Vec3(2,3,0),color=ur.rgb(i/100,0,0),collider='box'))
    ObjList.append(ur.Entity(model='cube',scale=(1,1,1),position=ur.Vec3(3,4,0),color=ur.rgb(i/100,0,0),collider='box'))
    ObjList.append(ur.Entity(model='cube',scale=(5,3,5),position=ur.Vec3(6,4,0),color=ur.rgb(i/100,0,0),collider='box'))
    
ur.invoke(createstairs,delay=2)
player.camera_pivot.y = playerdefheight 
vel = 0
sliding = False
def start_slide():
    global sliding, slide_timer, target_height,hdir,vel,player_capsule,offset,canslide,canfasttr,playerRot
    canslide = False
    canfasttr = False
    player_capsule.set_play_rate(1,player_capsule.getAnimNames()[0])
    player_capsule.play(player_capsule.getAnimNames()[0])
    vel = 10 + player_velocity.length()/10
    player.jump_height = 0
    player.speed = 0
    hdir = ur.Vec3(ur.camera.forward.x,0,ur.camera.forward.z).normalized()
    playerRot = -player.rotation.y
    sliding = True
    slide_timer = 0
    target_height = playerdefheight / 2  # crouch height
def SUlerpHeights():
    global offset
    if(round(player.camera_pivot.y,15) != playerdefheight):
        player.camera_pivot.y = ur.lerp(player.camera_pivot.y, playerdefheight, 12 * ur.time.dt)
    else:
        player.camera_pivot.y = playerdefheight
    if(round(offset,1) != 0):
        offset = round(ur.lerp(offset, 0, 12 * ur.time.dt),1)
    else:
        offset = 0
    print(round(player.camera_pivot.y,1),playerdefheight,round(offset,1),0,round(player.camera_pivot.y,1) == playerdefheight,round(offset) == 0)
    if(round(player.camera_pivot.y,1) == playerdefheight and round(offset,1) == 0):
        print("done")
    else:
        ur.invoke(SUlerpHeights,delay=0.01)
def stand_up():
    global offset
    global sliding, slide_timer, target_height,canfasttr,canslide
    SUlerpHeights()
    player_capsule.setPlayRate(-15,player_capsule.getAnimNames()[0])
    player_capsule.play(player_capsule.getAnimNames()[0])
    slide_timer = 0
    target_height = playerdefheight  # full height
    player.jump_height = playerdefjumpheight
    player.speed = 10
    sliding = False
    canfasttr = True
    canslide = True
def start_dash():
    global fasttring,hdir,leftdashdistance,canslide,canfasttr
    hdir = ur.camera.forward.normalized()
    fasttring = True
    canslide = False
    canfasttr = False
    player.jump_height = 0
    player.speed = 0
    leftdashdistance = dashdistance
def stop_dash():
    global canfasttr,canslide,fasttring
    player.speed = 10
    player.jump_height = playerdefjumpheight
    fasttring = False
    canslide = True
    canfasttr = True
def update():
    global hdir,offset,canfasttr,canslide,playerdefheight,playerdefjumpheight,sliding,vel,j,player,sliding,slide_timer,fasttring,leftdashdistance,timer
    updatecappos()
    if canslide and ur.held_keys['left control'] or canslide and ur.held_keys["c"]:
        start_slide()
    if sliding:
        boxray = ur.boxcast(ur.Vec3(player.position.x,player.position.y +3,player.z), hdir,thickness=player_size,debug=True)
        if(not boxray.hit):
            slide_timer += ur.time.dt
            t = min(slide_timer / 2, 1)  # 0 → 1
            player.camera_pivot.y = round(ur.lerp(player.camera_pivot.y, playerdefheight/1.5, 12 * ur.time.dt),1)
            offset = round(-ur.lerp(offset, playerdefheight*2, 1 * ur.time.dt),100)
            print(offset)
            player.position += hdir * vel * ur.time.dt
            vel -= 0.1
        if (sliding and ur.held_keys['space']) or vel < 3 or boxray.hit:
            stand_up()
    if(ur.held_keys["left shift"] and canfasttr):
        start_dash()
    if(fasttring):
        if(leftdashdistance > 0):
            player.position += ur.camera.forward *dashspeed * ur.time.dt
            leftdashdistance -= 1
            timer += ur.time.dt
            if timer > 1:
                timer = 0
                print("time")
            if(canfasttr and ur.held_keys["left control"] or canfasttr and ur.held_keys["c"]):
                stop_dash()
        else:
            stop_dash()
    if timer > 10:
        timer = 0
        print("time")
def playerMovement():
    global prev_position, player_velocity,hdir
    hdir = ur.Vec3(0,0,0)
    while True:
        global lockmouse
        if player.Y < -10 or player.Y > 1000:
            player.position = ur.Vec3(0,10,0)
        if(ur.held_keys["escape"]):
            lockmouse = not lockmouse
            ur.mouse.locked = lockmouse
            ur.mouse.visible = not lockmouse
        if(ur.time.dt > 0):
            player_velocity = (player.position - prev_position) / ur.time.dt
            prev_position = player.position
        ur.time.sleep(0.1)
def updatecappos():
    global sliding, offset,hdir,playerRot
    if(not sliding):
        player_capsule.set_h(-player.rotation.y)
        player_capsule.set_pos(player.x,player.y + player.camera_pivot.y - 1.5 + offset,player.z)
    else:
        player_capsule.setH(playerRot+180)
        player_capsule.set_pos(player.x,player.y + 1.1 + offset,player.z)
    if(hdir is not None):
        player_capsule2.setH((-player.rotation.y)+180)
th.Thread(target=playerMovement,args=()).start()
app.run()