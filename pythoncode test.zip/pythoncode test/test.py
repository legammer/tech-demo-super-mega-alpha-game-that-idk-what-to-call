import ursina as u
from direct.actor.Actor import Actor
import threading as th
app = u.Ursina()
render: u.NodePath
player = Actor('humanoid.glb')
player.reparentTo(render)
player.setScale(1)
player.setPos(0, 0, 0)
timer = 0
i = True
print(player.getAnimNames())
def nothing():
    print("1.5")
    pass
def update():
        global timer,i
        if(u.held_keys["z"] or u.held_keys["space"]):
            if(i):
                player.setY(u.lerp(player.get_y(), 10,u.time.dt))
            player.setPlayRate(-1,player.getAnimNames()[0])
            player.play(player.getAnimNames()[0])
            u.invoke(nothing,delay=1.5)
            player.setPlayRate(1,player.getAnimNames()[0])
            player.play(player.getAnimNames()[0])
            u.invoke(nothing,delay=1.5)
            i = False
        else:
            player.play(player.getAnimNames()[0],fromFrame=40)
            u.time.sleep(0.1)
app.run()